Biological Regrowth in EPANET Example Network Net3
==================================================

This example models biological regrowth in the standard EPANET
example network Net3. The files included are:

  net3.inp      --  the EPANET network input file set up to compute
                    average conditions over the last 48 hours of a
                    360 hour simulation
  net3-bio.msx  --  the MSX reaction file
  net3-bio-[gc|vc].msx -- the MSX reaction file with COMPILER
                    option turned on
  net3-bio.rpt  --  the report file containing the MSX results
