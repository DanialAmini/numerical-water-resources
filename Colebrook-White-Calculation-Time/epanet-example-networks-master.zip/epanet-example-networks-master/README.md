# epanet-example-networks

Adding Tests to nrtestsuite

1) Add the tests

2) Commit new tests to repo and tag it

3) Generate benchmark artifacts

4) Create release and upload artifacts 

5) Update test scripts and commit

6) Check testing is operational

